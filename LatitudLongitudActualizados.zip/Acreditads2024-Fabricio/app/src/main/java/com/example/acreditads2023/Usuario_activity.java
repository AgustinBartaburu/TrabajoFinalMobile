package com.example.acreditads2023;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.HttpException;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;




public class Usuario_activity extends AppCompatActivity {
    private EditText edtNombreUsuario;
    private EditText edtApellidoUsuario;
    private EditText edtDocUsuario;
    private EditText edtEmailUsuario;
    private EditText edtTipoUsuario;

    private CheckBox checkboxTerminos;
    private Database db;
    private Button btnRegistro;
    private Button btnVolver;
    private String idPlanilha = "1g6dIJTiR-4eIzbnwKUK6sXDjC6GYMCRElsbr_bVxPDQ";

    private static final String CHANNEL_ID = "canal";

    private static final int REQUEST_NOTIFICATION_PERMISSION = 1;

    private RequestQueue requestQueue;

    String range = "Sheet1A1:B2";
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.usuario_activity);
        requestQueue = Volley.newRequestQueue(this);
        btnRegistro = findViewById(R.id.btnRegistro);
        btnVolver = findViewById(R.id.btnVolver);
        edtNombreUsuario = findViewById(R.id.edtNombreUsuario);
        edtApellidoUsuario = findViewById(R.id.edtApellidoUsuario);
        edtDocUsuario = findViewById(R.id.edtDocUsuario);
        edtEmailUsuario = findViewById(R.id.edtEmailUsuario);
        edtTipoUsuario = findViewById(R.id.edtTipoUsuario);
        checkboxTerminos = findViewById(R.id.checkbox_terminos);

        db = new Database(getApplicationContext());

        // Obtener referencia al TextView de "Términos y Condiciones"
        TextView textTerminos = findViewById(R.id.text_terminos);

        // Configurar el clic en "Términos y Condiciones" para iniciar la descarga del PDF
        textTerminos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Llamar al método para descargar el PDF
                descargarPDF();
            }
        });

        btnRegistro = findViewById(R.id.btnRegistro);
        btnRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!checkboxTerminos.isChecked()) {
                    // Mostrar mensaje si no se aceptan los términos y condiciones
                    Toast.makeText(getApplicationContext(), "Debe aceptar los términos y condiciones", Toast.LENGTH_LONG).show();
                    return;
                }
                Usuario u = new Usuario();
                // Llamar al método verificarPermisoNotificaciones() después de que el usuario se registre con éxito
                verificarPermisoNotificaciones();
                u.setNombreUsuario(edtNombreUsuario.getText().toString());
                u.setApellidoUsuario(edtApellidoUsuario.getText().toString());
                u.setDocUsuario(edtDocUsuario.getText().toString());
                u.setEmailUsuario(edtEmailUsuario.getText().toString());
                u.setTipoUsuario(Integer.parseInt(edtTipoUsuario.getText().toString()));

                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("https://api.zerobounce.net/")
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();

                Consulta_validacion correo = new Consulta_validacion();
                correo.setEmail(u.getEmailUsuario());

                // Google Sheets URL
                String urlSheets = "https://script.google.com/macros/s/AKfycbwo4OPDNV5K_DdrmZoVrY-Mng3X0zmwW3FVMYdLDAzKBZ35AXifkwl3fdTg9T_A6jTg/exec?action=inserir&nome=" +
                        edtNombreUsuario.getText().toString() + "&sobrenome=" + edtApellidoUsuario.getText().toString() +
                        "&documento=" + edtDocUsuario.getText().toString() + "&email=" + edtEmailUsuario.getText().toString() + "&tipoUsuario=" + edtTipoUsuario.getText().toString();

                //aaaaaaa
                StringRequest stringRequest = new StringRequest(Request.Method.GET, urlSheets, new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        Log.i("Response", s);
                    }
                }, new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(com.android.volley.VolleyError error) {
                        Log.e("Error", error.toString());
                        Toast.makeText(getApplicationContext(), "Error al crear el Usuario", Toast.LENGTH_LONG).show();
                    }
                });

                requestQueue.add(stringRequest);

                api_email request = retrofit.create(api_email.class);
                request.consulta_correo(correo.getClave(), correo.getEmail()).enqueue(new Callback<retorno_validacion>() {
                    @Override
                    public void onResponse(Call<retorno_validacion> call, Response<retorno_validacion> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            retorno_validacion retorno = response.body();
                            Toast.makeText(getApplicationContext(), retorno.getAddress(), Toast.LENGTH_LONG).show();
                            if ("valid".equals(retorno.getStatus())) {
                                UsuarioDAO uDAO = new UsuarioDAO(db);
                                uDAO.salvar(u);
                                Toast.makeText(getApplicationContext(), "Usuario registrado con éxito", Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(getApplicationContext(), "Digite un email válido", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "Error en la validación del correo", Toast.LENGTH_LONG).show();
                        }
                    }
                    @Override
                    public void onFailure(Call<retorno_validacion> call, Throwable t) {
                        Log.e("Error", t.getMessage(), t);
                        Toast.makeText(getApplicationContext(), "Error en la conexión: " + t.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        });

        btnVolver = findViewById(R.id.btnVolver);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
    private void verificarPermisoNotificaciones() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Verificar si el permiso de notificación está concedido
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                // Solicitar permiso de notificación
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATION_PERMISSION);
            } else {
                // Permiso ya concedido
                Toast.makeText(this, "Permisos de notificación ya concedidos", Toast.LENGTH_SHORT).show();
                configurarCanalNotificacion();
                enviarNotificacion();
            }
        } else {
            // No es necesario solicitar permisos en versiones anteriores a Android 13
            configurarCanalNotificacion();
            enviarNotificacion();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_NOTIFICATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permiso concedido, configurar el canal de notificación
                configurarCanalNotificacion();
                enviarNotificacion();
            } else {
                // Permiso denegado
                Toast.makeText(getApplicationContext(), "Error al crear Usuario", Toast.LENGTH_SHORT).show();

            }
        }
    }

    private void configurarCanalNotificacion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Canal de notificaciones", NotificationManager.IMPORTANCE_DEFAULT);
            // Configurar otras propiedades del canal, si es necesario
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private void enviarNotificacion() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification) // Icono de la notificación
                .setContentTitle("Creacion de Usuario")
                .setContentText("Usuario creado con exito!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManager.notify(1, builder.build());
    }
    private void descargarPDF() {
        // URL del PDF para descargar
        String urlPDF = "https://drive.google.com/file/d/178com7W9Ct-O2i3kSdeBHNHrtFdOOHvo/view";

        // Crear un Intent para abrir el navegador y descargar el PDF desde la URL
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(urlPDF));
        startActivity(intent);
    }
}
