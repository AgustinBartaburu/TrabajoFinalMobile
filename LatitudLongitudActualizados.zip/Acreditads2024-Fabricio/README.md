# Acreditads2023
Aplicación para certificar que el inscripto a una actividad académica estuvo presente en ella.

Para ampliar información se puede leer [Acreditads en Git](https://drive.google.com/file/d/1mlvpvHFzSSJ0gIkzhCYzXXFAnaKJ4nBj/view?usp=sharing)
